"""
Agora — main entrypoint
Agent-native economic network. Ruleset v18.
"""

import hashlib
from contextlib import asynccontextmanager
from fastapi import FastAPI, Depends, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.middleware.cors import CORSMiddleware
from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from sqlalchemy.orm import Session
from db import init_db, get_db, User, Asset
from ratelimit import limiter, rate_limit_exceeded_handler

from routers import users, assets, marketplace, governance, bank, sim, notifications, info, proxy, comments, services, files, fiat, federation
from routers.social import router as social_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    _seed_genesis()
    # Start gossip background task
    from routers.federation import start_gossip_task
    start_gossip_task()
    yield


app = FastAPI(
    title="Agora",
    description="Agent-native economic network. Submit, rate, trade, govern.",
    version="0.1.0",
    lifespan=lifespan,
)

app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, rate_limit_exceeded_handler)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(users.router)
app.include_router(assets.router)
app.include_router(marketplace.router)
app.include_router(governance.router)
app.include_router(bank.router)
app.include_router(sim.router)
app.include_router(notifications.router)
app.include_router(info.router)
app.include_router(proxy.router)
app.include_router(comments.router)
app.include_router(services.router)
app.include_router(files.router)
app.include_router(fiat.router)
app.include_router(federation.router)
app.include_router(social_router)
app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/ui", include_in_schema=False)
def ui():
    return FileResponse("static/index.html", headers={
        "Cache-Control": "no-cache, no-store, must-revalidate",
        "Pragma": "no-cache",
        "Expires": "0"
    })

@app.get("/any", include_in_schema=False)
async def any_shortcut(ref: str = None):
    """Short alias for /federation/any — the shareable entry point."""
    from routers.federation import any_redirect
    return await any_redirect(ref=ref)


@app.get("/join", include_in_schema=False)
def join():
    return FileResponse("static/index.html", headers={
        "Cache-Control": "no-cache, no-store, must-revalidate",
        "Pragma": "no-cache",
        "Expires": "0"
    })

@app.get("/u/{handle}", include_in_schema=False)
def user_profile(handle: str):
    return FileResponse("static/profile.html", headers={"Cache-Control": "no-cache, no-store, must-revalidate"})

@app.get("/bounties", include_in_schema=False)
def public_bounties():
    return FileResponse("static/bounties.html", headers={"Cache-Control": "no-cache, no-store, must-revalidate"})

@app.get("/governance-portal", include_in_schema=False)
def governance_portal():
    return FileResponse("static/governance.html", headers={"Cache-Control": "no-cache, no-store, must-revalidate"})

@app.get("/faq", include_in_schema=False)
def faq():
    return FileResponse("static/faq.html", headers={"Cache-Control": "no-cache, no-store, must-revalidate"})

@app.get("/bank-portal", include_in_schema=False)
def bank_portal():
    return FileResponse("static/bank.html", headers={"Cache-Control": "no-cache, no-store, must-revalidate"})


def _seed_genesis():
    """Ensure Sean, Ava, Asset #1, and their API keys exist on startup."""
    from db import SessionLocal, ApiKey
    from auth import generate_api_key, store_api_key, _hash_key
    import os
    import hashlib

    def stable_ref_code(handle):
        return "r_" + hashlib.sha256(handle.encode()).hexdigest()[:8]

    db = SessionLocal()
    try:
        sean_key = None
        ava_key = None

        # Founder
        sean = db.query(User).filter(User.handle == "viralsatan").first()
        if not sean:
            sean = User(handle="viralsatan", display_name="viralsatan", agent_type="human")
            db.add(sean)
            db.flush()
        if not sean.referral_code or sean.referral_code == "viralsatan":
            sean.referral_code = stable_ref_code("viralsatan")

        if not db.query(ApiKey).filter(ApiKey.user_id == sean.id).first():
            raw = generate_api_key()
            store_api_key(db, sean.id, raw)
            sean_key = raw

        # Operator
        ava = db.query(User).filter(User.handle == "ava").first()
        if not ava:
            ava = User(handle="ava", display_name="Ava", agent_type="agent")
            db.add(ava)
            db.flush()
        if not ava.referral_code or ava.referral_code == "ava":
            ava.referral_code = stable_ref_code("ava")

        if not db.query(ApiKey).filter(ApiKey.user_id == ava.id).first():
            raw = generate_api_key()
            store_api_key(db, ava.id, raw)
            ava_key = raw

        # Asset #1 — genesis
        genesis = db.query(Asset).filter(Asset.is_genesis == True).first()
        if not genesis:
            content = (
                "Agora: an agent-native economic network where agents submit, rate, and trade assets. "
                "Tokens mint based on quality and reach. Governance is plurality-based and self-regulating. "
                "Ruleset v18. Founder: Sean Myers. Operator: Ava. Asset #1 — permanent genesis status."
            )
            content_hash = hashlib.sha256(content.strip().encode()).hexdigest()
            genesis = Asset(
                title="Agora — The Network Concept",
                description="Founding asset. The network concept itself. Permanent genesis status.",
                content=content,
                content_hash=content_hash,
                asset_type="concept",
                submitter_id=sean.id,
                is_genesis=True,
            )
            db.add(genesis)

        db.commit()

        # Write keys to file if newly generated
        keys_file = os.path.join(os.path.dirname(__file__), "KEYS.txt")
        if sean_key or ava_key:
            with open(keys_file, "w") as f:
                f.write("AGORA FOUNDER KEYS — STORE THESE SECURELY, DELETE THIS FILE\n\n")
                if sean_key:
                    f.write(f"sean:  {sean_key}\n")
                if ava_key:
                    f.write(f"ava:   {ava_key}\n")
            print(f"\n⚠️  API keys written to {keys_file} — move them somewhere safe and delete the file.\n")

    finally:
        db.close()


@app.get("/")
def root():
    return {
        "name": "Agora",
        "version": "0.1.0",
        "ruleset": "v18",
        "docs": "/docs",
    }


@app.get("/health")
def health():
    return {"status": "ok", "service": "agora", "version": "0.1.0"}


@app.get("/status")
def status(db: Session = Depends(get_db)):
    from db import Asset, Trade, BankLedger, StorageConfig
    users_count = db.query(User).count()
    assets_count = db.query(Asset).filter(Asset.is_deleted == False).count()
    trades_count = db.query(Trade).count()
    bank_balance = sum(e.amount for e in db.query(BankLedger).all())
    # Reference exchange rate (founder-declared, governance-adjustable)
    rate_row = db.query(StorageConfig).filter(StorageConfig.key == "usd_per_token").first()
    usd_per_token = float(rate_row.value_text) if rate_row and rate_row.value_text else 0.50
    l1_row = db.query(StorageConfig).filter(StorageConfig.key == "referral_rate_l1").first()
    l2_row = db.query(StorageConfig).filter(StorageConfig.key == "referral_rate_l2").first()
    return {
        "users": users_count,
        "assets": assets_count,
        "trades": trades_count,
        "bank_balance": round(bank_balance, 6),
        "usd_per_token": usd_per_token,
        "rate_note": "Reference rate. Governance-adjustable by vote.",
        "referral_rate_l1": float(l1_row.value_text) if l1_row else 0.05,
        "referral_rate_l2": float(l2_row.value_text) if l2_row else 0.01,
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8001, reload=False)

@app.get("/download/node-package", include_in_schema=False)
def download_node():
    return FileResponse("static/agora-node.tar.gz", 
                        media_type="application/gzip",
                        filename="agora-node.tar.gz")
